package com.example.jbdl9.youtubeproject.youtubeproject;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class YoutubeController {

    @Autowired
    VideoRepository videoRepository;

    @Autowired
    VideoCriteriaRepository videoCriteriaRepository;

    @GetMapping("/get_videos")
    public List<Video> getVideos(@RequestParam("query") String query, @RequestParam(value = "pageNo", defaultValue = "1", required = false)
            int pageNo, @RequestParam(value = "pageSize", defaultValue ="10", required = false ) int pageSize){


        return videoCriteriaRepository.getAllVideo(query,pageNo,pageSize);
        //return videoRepository.getVideos(query);
    }
}
