package com.example.jbdl9.youtubeproject.youtubeproject;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class VideoCriteriaRepository {

    private final EntityManager entityManager;
    private final CriteriaBuilder criteriaBuilder;

    public VideoCriteriaRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
        criteriaBuilder=entityManager.getCriteriaBuilder();
    }


    public List<Video> getAllVideo(String query,int pageNo,int pageSize)
    {

        // this defines on which entity we want criteria
        CriteriaQuery<Video> criteriaQuery=criteriaBuilder.createQuery(Video.class);
        // root defines what type of result we will get from query
        Root<Video> videoRoot=criteriaQuery.from(Video.class);
        // predicate will filter the results

        Predicate p1=criteriaBuilder.equal(videoRoot.get("tag"),query);
        criteriaQuery.where(p1);
        TypedQuery<Video> typedQuery=entityManager.createQuery(criteriaQuery);
        typedQuery.setFirstResult((pageNo-1)*pageSize).setMaxResults(pageSize);

        List<Video> video=typedQuery.getResultList();
        return video;
    }

    public void createIndex(String fieldName)
    {

    }



}
