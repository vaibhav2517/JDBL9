package com.example.jbdl9.youtubeproject.youtubeproject;

import com.example.jbdl9.youtubeproject.youtubeproject.Video;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.SearchResultSnippet;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class VideoService {

    @Value("${app.youtube.api.key}")
    public String apiKey;

    @Autowired
    VideoRepository videoRepository;

    private static Logger logger= LoggerFactory.getLogger(Video.class);

    private YouTube youTube;
    private String pageToken;

    VideoService()
    {
        HttpTransport httpTransport=new NetHttpTransport();
        JsonFactory jsonFactory=new JacksonFactory();

        this.youTube = new YouTube.Builder(httpTransport, jsonFactory, new HttpRequestInitializer() {
            @Override
            public void initialize(HttpRequest httpRequest) throws IOException {

            }
        }).build();
    }


    public void fetchVideos(List<String> keywords){



        for(int i=0;i<keywords.size();i++)
        {
            VideoThread thread=new VideoThread(keywords.get(i),youTube,videoRepository,apiKey);
            thread.start();
        }




    }



    public void loadVideosInDB(String keyword) throws IOException, ParseException {


        /*YouTube.Search.List searchList = (YouTube.Search.List) youTube.search().list("id,snippet");
        searchList.setKey(this.apiKey);
        searchList.setQ(keyword);
        searchList.setMaxResults(3L);
        searchList.setPageToken(this.pageToken);

        SearchListResponse response=searchList.execute();
        List<SearchResult> items=response.getItems();
        logger.warn("the items in the response are {}",response);

         List<Video> videoList=new ArrayList<>();
        for(SearchResult result:items)
        {
            SearchResultSnippet snippet=result.getSnippet();
            String id=result.getId().getVideoId();
            String channelTitle=snippet.getChannelTitle();
            String channelId=snippet.getChannelId();
            String title=snippet.getTitle();
            String description=snippet.getDescription();
            String tag=result.getEtag();
            JSONObject thumbnails= (JSONObject) JSONValue.parseWithException(snippet.getThumbnails().toString());

            videoList.add(new Video(id,title,description,thumbnails,channelId,channelTitle,tag));




        }
        videoRepository.saveAll(videoList);
        this.pageToken=response.getNextPageToken();*/

        /*List<Video> mylist=videoRepository.findAll();
        logger.warn("thumbnail data");
        for(Video video:mylist)
        {
            System.out.println(video.getThumbnailUrl());
        }*/

    }

}
