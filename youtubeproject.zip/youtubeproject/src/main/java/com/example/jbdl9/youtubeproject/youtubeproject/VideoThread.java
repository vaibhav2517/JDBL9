package com.example.jbdl9.youtubeproject.youtubeproject;

import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.SearchResultSnippet;
import org.hibernate.exception.ConstraintViolationException;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

public class VideoThread extends Thread {

    private static Logger logger= LoggerFactory.getLogger(VideoThread.class);

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public YouTube getYouTube() {
        return youTube;
    }

    public void setYouTube(YouTube youTube) {
        this.youTube = youTube;
    }

    public VideoRepository getVideoRepository() {
        return videoRepository;
    }

    public void setVideoRepository(VideoRepository videoRepository) {
        this.videoRepository = videoRepository;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getPageToken() {
        return pageToken;
    }

    public void setPageToken(String pageToken) {
        this.pageToken = pageToken;
    }

    public List<Video> getVideoList() {
        return videoList;
    }

    public void setVideoList(List<Video> videoList) {
        this.videoList = videoList;
    }

    private String keyword;
    private YouTube youTube;
    private VideoRepository videoRepository;
    private String apiKey;
    private String pageToken;
    private List<Video> videoList=new ArrayList<>();



    VideoThread(String keyword,YouTube youTube,VideoRepository videoRepository,String apiKey)
    {
        this.keyword=keyword;
        this.youTube=youTube;
        this.videoRepository=videoRepository;
        this.apiKey=apiKey;

    }



    @Override
    public void run() {

        int i = 0;

        while (i < 4) {

            YouTube.Search.List searchList = null;
            try {
                searchList = (YouTube.Search.List) youTube.search().list("id,snippet");
            } catch (IOException e) {
                e.printStackTrace();
            }
            searchList.setKey(this.apiKey);
            searchList.setQ(keyword);
            searchList.setMaxResults(5L);
            searchList.setPageToken(this.pageToken);

            SearchListResponse response = null;
            try {
                response = searchList.execute();
            } catch (IOException e) {
                e.printStackTrace();
            }
            List<SearchResult> items = response.getItems();


            for (SearchResult result : items) {
                SearchResultSnippet snippet = result.getSnippet();
                String id = result.getId().getVideoId();
                String channelTitle = snippet.getChannelTitle();
                String channelId = snippet.getChannelId();
                String title = snippet.getTitle();
                String description = snippet.getDescription();
                String tag = keyword;
                JSONObject thumbnails = null;
                try {
                    thumbnails = (JSONObject) JSONValue.parseWithException(snippet.getThumbnails().toString());
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                videoList.add(new Video(id, title, description, thumbnails, channelId, channelTitle, tag));


            }
                try {
                    videoRepository.saveAll(videoList);
                }
                catch (DataIntegrityViolationException e)
                {
                    logger.error("Exception: {}",e.getMessage());

                    for(Video video:videoList)
                    {
                        try{
                            videoRepository.save(video);
                        }
                        catch (DataIntegrityViolationException e1)
                        {
                            logger.error("Duplicate Key Exception: {}", e1.getMessage());
                        }
                    }


                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }

            this.pageToken = response.getNextPageToken();
            logger.warn("saved video in thread {}", currentThread().getName(), keyword);
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            i++;
        }

    }

}
