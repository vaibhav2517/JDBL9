package com.example.jbdl9.youtubeproject.youtubeproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class YoutubeprojectApplication implements CommandLineRunner {

	List<String> keywords= Arrays.asList("football");

	@Autowired
   VideoService videoService;

	public static void main(String[] args) {
		SpringApplication.run(YoutubeprojectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		//videoService.fetchVideos(keywords);
        //videoService.loadVideosInDB("cricket");

	}
}
