package com.example.jbdl9.youtubeproject.youtubeproject;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface VideoRepository extends JpaRepository<Video,String> {

    @Query("select v from Video v where v.tag=:key")
    public List<Video> getVideos(String key);


}
